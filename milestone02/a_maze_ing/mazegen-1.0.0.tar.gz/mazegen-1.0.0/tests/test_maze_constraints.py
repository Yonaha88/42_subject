"""Verification tests for the maze-validity rules in the project subject.

Not part of the reusable ``mazegen`` package or the grading criteria (see
the subject's "Additional Guidelines"), but kept in the repository to make
the constraints below independently checkable: wall coherence, border
closure, absence of 3x3-or-larger open blocks, corner/centre openness and
low dead-end count for ``PERFECT=False``, and exact spanning-tree structure
for ``PERFECT=True``.

Run with: python3 -m unittest tests/test_maze_constraints.py
"""

import random
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mazegen import MazeGenerator  # noqa: E402

SIZES_AND_SEEDS = [
    (3, 9, 3),
    (7, 5, 1),
    (10, 12, 42),
    (20, 15, 7),
    (30, 20, 123),
]


def _make_maze(
    width: int, height: int, seed: int, perfect: bool
) -> MazeGenerator:
    gen = MazeGenerator()
    gen._width = width
    gen._height = height
    gen._forty_two = gen._compute_forty_two()
    gen._entry = (0, 0)
    gen._exit = (width - 1, height - 1)
    gen._outputfile = "/dev/null"
    gen._is_perfect = perfect
    gen._seed = seed
    random.seed(seed)
    gen._generate_and_save()
    return gen


def _non_forty_two_cells(gen: MazeGenerator) -> list[tuple[int, int]]:
    return [c for c in gen.walls if c not in gen._forty_two]


def _open_edge_count(gen: MazeGenerator) -> int:
    count = 0
    for (x, y), mask in gen.walls.items():
        if (x, y) in gen._forty_two:
            continue
        east = (x + 1, y)
        if (
            not (mask & 2)
            and east in gen.walls
            and east not in gen._forty_two
        ):
            count += 1
        south = (x, y + 1)
        if (
            not (mask & 4)
            and south in gen.walls
            and south not in gen._forty_two
        ):
            count += 1
    return count


def _has_3x3_open_block(gen: MazeGenerator) -> bool:
    for y in range(gen.height - 2):
        for x in range(gen.width - 2):
            cells = [(x + i, y + j) for i in range(3) for j in range(3)]
            if any(c in gen._forty_two for c in cells):
                continue
            if all(not gen.walls[c] & 4 for c in cells if c[1] < y + 2):
                if all(not gen.walls[c] & 2 for c in cells if c[0] < x + 2):
                    return True
    return False


class WallCoherenceTests(unittest.TestCase):
    def test_shared_walls_agree_and_border_is_closed(self) -> None:
        for width, height, seed in SIZES_AND_SEEDS:
            gen = _make_maze(width, height, seed, perfect=False)
            with self.subTest(width=width, height=height, seed=seed):
                for (x, y), mask in gen.walls.items():
                    east = (x + 1, y)
                    if east in gen.walls:
                        self.assertEqual(
                            bool(mask & 2), bool(gen.walls[east] & 8)
                        )
                    else:
                        self.assertTrue(
                            mask & 2, f"east border open at {(x, y)}"
                        )
                    south = (x, y + 1)
                    if south in gen.walls:
                        self.assertEqual(
                            bool(mask & 4), bool(gen.walls[south] & 1)
                        )
                    else:
                        self.assertTrue(
                            mask & 4, f"south border open at {(x, y)}"
                        )
                    if x == 0:
                        self.assertTrue(
                            mask & 8, f"west border open at {(x, y)}"
                        )
                    if y == 0:
                        self.assertTrue(
                            mask & 1, f"north border open at {(x, y)}"
                        )


class NoLargeOpenAreaTests(unittest.TestCase):
    def test_no_3x3_open_block(self) -> None:
        for width, height, seed in SIZES_AND_SEEDS:
            gen = _make_maze(width, height, seed, perfect=False)
            with self.subTest(width=width, height=height, seed=seed):
                self.assertFalse(_has_3x3_open_block(gen))


class PacManModeTests(unittest.TestCase):
    def test_corners_and_centre_are_open(self) -> None:
        for width, height, seed in SIZES_AND_SEEDS:
            gen = _make_maze(width, height, seed, perfect=False)
            corners = [
                (0, 0), (width - 1, 0),
                (0, height - 1), (width - 1, height - 1),
            ]
            centre = (width // 2, height // 2)
            with self.subTest(width=width, height=height, seed=seed):
                for corner in corners:
                    self.assertLess(bin(gen.walls[corner]).count("1"), 3)
                self.assertLess(bin(gen.walls[centre]).count("1"), 3)

    def test_dead_ends_are_rare(self) -> None:
        for width, height, seed in SIZES_AND_SEEDS:
            gen = _make_maze(width, height, seed, perfect=False)
            non_42 = _non_forty_two_cells(gen)
            dead_ends = sum(
                1 for c in non_42 if bin(gen.walls[c]).count("1") == 3
            )
            with self.subTest(width=width, height=height, seed=seed):
                self.assertLessEqual(dead_ends, len(non_42) // 10)

    def test_at_least_two_independent_routes(self) -> None:
        for width, height, seed in SIZES_AND_SEEDS:
            gen = _make_maze(width, height, seed, perfect=False)
            non_42 = _non_forty_two_cells(gen)
            loop_count = _open_edge_count(gen) - (len(non_42) - 1)
            with self.subTest(width=width, height=height, seed=seed):
                self.assertGreaterEqual(loop_count, 2)


class PerfectModeTests(unittest.TestCase):
    def test_is_exact_spanning_tree(self) -> None:
        for width, height, seed in SIZES_AND_SEEDS:
            gen = _make_maze(width, height, seed, perfect=True)
            non_42 = _non_forty_two_cells(gen)
            with self.subTest(width=width, height=height, seed=seed):
                self.assertEqual(_open_edge_count(gen), len(non_42) - 1)


class ReproducibilityTests(unittest.TestCase):
    def test_same_seed_reproduces_identical_maze(self) -> None:
        first = _make_maze(10, 12, 42, perfect=False)
        second = _make_maze(10, 12, 42, perfect=False)
        self.assertEqual(first.walls, second.walls)
        self.assertEqual(first.solution, second.solution)


if __name__ == "__main__":
    unittest.main()
